%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Cleaning
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all, close all, home

%Loading in a signal and applying various signal 
%operations to it and then graphing the results to 
%better model the impact of these operations

%Puts audio data from laughter audio into S
S=load('laughter'); 
x=S.y; fs=S.Fs;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Original
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Time (Discrete)
n=1:length(x);

% Time (Continuous-Time)
t=[1:(length(x))]/fs;

subplot(211)
stem(n,x,'Color', 'k'),grid
xlabel('n','FontSize',16,'FontAngle','italic')
ylabel('x[n]','FontSize',16,'FontAngle','italic')
title('Discrete Time Signal for laughgter','FontSize',16)
set(gca,'FontSize',16)

subplot(212)
plot(t,x,'Color', 'k'),grid
xlabel('t','FontSize',16,'FontAngle','italic')
ylabel('x(t)','FontSize',16,'FontAngle','italic')
title('Continuous Time Signal for laughter','FontSize',16)
set(gca,'FontSize',16)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%LPF
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Function (Kronecker Delta Function)
KronDel=@(n) heaviside(n)-heaviside(n-1)

% Discrete Times (System)
n=1:length(x);

% Signals (System)
h_lpf=0.0016*KronDel(n)+0.0057*KronDel(n-1)+0.0089*KronDel(n-2)+...
    0.0011*KronDel(n-3)-0.0240*KronDel(n-4)-0.0537*KronDel(n-5)-...
    0.0530*KronDel(n-6)+0.012*KronDel(n-7)+0.1361*KronDel(n-8)+...
    0.2621*KronDel(n-9)+0.3155*KronDel(n-10)+0.2621*KronDel(n-11)+...
    0.1361*KronDel(n-12)+0.0120*KronDel(n-13)-0.0530*KronDel(n-14)-...
    0.0537*KronDel(n-15)-0.0240*KronDel(n-16)+0.0011*KronDel(n-17)+...
    0.0089*KronDel(n-18)+0.0057*KronDel(n-19)+0.0016*KronDel(n-20);

% Signal (Output, Matlab)
y_lpf=conv(x,h_lpf);

figure
subplot(311)
stem(n,x,'fill','LineWidth',4,'Color','k','LineStyle','-'),grid
xlabel('n','FontSize',12,'FontAngle','italic')
ylabel('x[n]','FontSize',12,'FontAngle','italic')
title('Signal (Input)','FontSize',12)

subplot(312)
stem(n,h_lpf,'fill','LineWidth',4,'Color','k','LineStyle','-'),grid
xlabel('n','FontSize',12,'FontAngle','italic')
ylabel('h[n]','FontSize',12,'FontAngle','italic')
title('Signal (System)','FontSize',12)

subplot(313)
stem(n,y_lpf,'fill','LineWidth',4,'Color','k','LineStyle','-'),grid
xlabel('n','FontSize',12,'FontAngle','italic')
ylabel('y_lpf[n]','FontSize',12,'FontAngle','italic')
title('Convolution (LPF Output)','FontSize',12)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%HPF
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Discrete Times (System)
n=1:length(x);

% Signals (System)
h_hpf=0.0041*KronDel(n)-0.0154*KronDel(n-1)+0.0110*KronDel(n-2)+...
    0.0171*KronDel(n-3)-0.0070*KronDel(n-4)-0.0348*KronDel(n-5)-...
    0.0103*KronDel(n-6)+0.0586*KronDel(n-7)+0.0648*KronDel(n-8)-...
    0.0797*KronDel(n-9)-0.3026*KronDel(n-10)+0.5883*KronDel(n-11)-...
    0.3026*KronDel(n-12)-0.0797*KronDel(n-13)+0.0648*KronDel(n-14)+...
    0.0586*KronDel(n-15)-0.0103*KronDel(n-16)-0.0348*KronDel(n-17)-...
    0.0070*KronDel(n-18)+0.0171*KronDel(n-19)+0.0110*KronDel(n-20)-...
    0.0154*KronDel(n-21)+0.0041*KronDel(n-22);

% Signal (Output, Matlab)
y_hpf=conv(x,h_hpf);

figure
subplot(311)
stem(n,x,'fill','LineWidth',4,'Color','k','LineStyle','-'),grid
xlabel('n','FontSize',12,'FontAngle','italic')
ylabel('x[n]','FontSize',12,'FontAngle','italic')
title('Signal (Input)','FontSize',12)

subplot(312)
stem(n,h_lpf,'fill','LineWidth',4,'Color','k','LineStyle','-'),grid
xlabel('n','FontSize',12,'FontAngle','italic')
ylabel('h[n]','FontSize',12,'FontAngle','italic')
title('Signal (System)','FontSize',12)

subplot(313)
stem(n,y_hpf,'fill','LineWidth',4,'Color','k','LineStyle','-'),grid
xlabel('n','FontSize',12,'FontAngle','italic')
ylabel('y_hpf[n]','FontSize',12,'FontAngle','italic')
title('Convolution (HPF Output)','FontSize',12)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%BPF
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Discrete Times (System)
n=1:length(x);

% Signals (System)
h_bpf=0.0016*KronDel(n)+0.0057*KronDel(n-1)+0.0089*KronDel(n-2)+...
    0.0011*KronDel(n-3)-0.0240*KronDel(n-4)-0.0537*KronDel(n-5)-...
    0.0530*KronDel(n-6)+0.012*KronDel(n-7)+0.1361*KronDel(n-8)+...
    0.2621*KronDel(n-9)+0.3155*KronDel(n-10)+0.2621*KronDel(n-11)+...
    0.1361*KronDel(n-12)+0.0120*KronDel(n-13)-0.0530*KronDel(n-14)-...
    0.0537*KronDel(n-15)-0.0240*KronDel(n-16)+0.0011*KronDel(n-17)+...
    0.0089*KronDel(n-18)+0.0057*KronDel(n-19)+0.0016*KronDel(n-20);

% Signal (Output, Matlab)
y_bpf=conv(x,h_bpf);

figure
subplot(311)
stem(n,x,'fill','LineWidth',4,'Color','k','LineStyle','-'),grid
xlabel('n','FontSize',12,'FontAngle','italic')
ylabel('x[n]','FontSize',12,'FontAngle','italic')
title('Signal (Input)','FontSize',12)

subplot(312)
stem(n,h_lpf,'fill','LineWidth',4,'Color','k','LineStyle','-'),grid
xlabel('n','FontSize',12,'FontAngle','italic')
ylabel('h[n]','FontSize',12,'FontAngle','italic')
title('Signal (System)','FontSize',12)

subplot(313)
stem(n,y_bpf,'fill','LineWidth',4,'Color','k','LineStyle','-'),grid
xlabel('n','FontSize',12,'FontAngle','italic')
ylabel('y_bpf[n]','FontSize',12,'FontAngle','italic')
title('Convolution (BPF Output)','FontSize',12)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%BSF
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Function (Kronecker Delta Function)
KronDel=@(n) heaviside(n)-heaviside(n-1)

% Discrete Times (System)
n=1:length(x);

% Signals (System)
h_bsf=0.0016*KronDel(n)+0.0057*KronDel(n-1)+0.0089*KronDel(n-2)+...
    0.0011*KronDel(n-3)-0.0240*KronDel(n-4)-0.0537*KronDel(n-5)-...
    0.0530*KronDel(n-6)+0.012*KronDel(n-7)+0.1361*KronDel(n-8)+...
    0.2621*KronDel(n-9)+0.3155*KronDel(n-10)+0.2621*KronDel(n-11)+...
    0.1361*KronDel(n-12)+0.0120*KronDel(n-13)-0.0530*KronDel(n-14)-...
    0.0537*KronDel(n-15)-0.0240*KronDel(n-16)+0.0011*KronDel(n-17)+...
    0.0089*KronDel(n-18)+0.0057*KronDel(n-19)+0.0016*KronDel(n-20);

% Signal (Output, Matlab)
y_bsf=conv(x,h_bsf);

figure
subplot(311)
stem(n,x,'fill','LineWidth',4,'Color','k','LineStyle','-'),grid
xlabel('n','FontSize',12,'FontAngle','italic')
ylabel('x[n]','FontSize',12,'FontAngle','italic')
title('Signal (Input)','FontSize',12)

subplot(312)
stem(n,h_lpf,'fill','LineWidth',4,'Color','k','LineStyle','-'),grid
xlabel('n','FontSize',12,'FontAngle','italic')
ylabel('h[n]','FontSize',12,'FontAngle','italic')
title('Signal (System)','FontSize',12)

subplot(313)
stem(n,y_bsf,'fill','LineWidth',4,'Color','k','LineStyle','-'),grid
xlabel('n','FontSize',12,'FontAngle','italic')
ylabel('y_bsf[n]','FontSize',12,'FontAngle','italic')
title('Convolution (BDF Output)','FontSize',12)